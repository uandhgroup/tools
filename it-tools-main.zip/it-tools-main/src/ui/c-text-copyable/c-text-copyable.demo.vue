<template>
  <c-text-copyable value="value" displayed-value="displayedValue" />
</template>
