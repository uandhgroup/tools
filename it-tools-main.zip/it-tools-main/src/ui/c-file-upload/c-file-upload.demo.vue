<template>
  <c-file-upload />
</template>
