<script lang="ts" setup>
import CLink from './c-link.vue';
</script>

<template>
  <div>
    <h2>Default</h2>
    <CLink mx-1>
      Link
    </CLink>
  </div>
</template>
