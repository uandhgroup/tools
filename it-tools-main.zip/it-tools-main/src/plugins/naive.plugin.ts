import { create } from 'naive-ui';

export const naive = create();
