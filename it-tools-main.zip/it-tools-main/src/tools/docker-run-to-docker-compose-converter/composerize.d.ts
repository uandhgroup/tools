declare module 'composerize' {
  const composerize: (arg: string) => string;
  export default composerize;
}
