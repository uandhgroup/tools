<template>
  <c-card w-full important:flex-1 important:pa-0>
    <c-diff-editor />
  </c-card>
</template>
